import { copyInvite } from "./clipboard";
import { IMAGE_HOSTS, IMAGE_REDIRECTS } from "../../packages/browser/src/profiles/public";
import { pasteInvite } from "./clipboard";
import { createLink, encodeInviteCode } from "@ghostly/core";
import { mkdtempSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { test as base, expect, type Browser, type BrowserContext, type Locator, type Page, type Request } from "@playwright/test";
import { shouldReloadAfterBoot } from "./bootReload";
import { MAINNET_MINTS, attachMint } from "./mint";
import { LocalRelay } from "./relay";
import { useLocalStun } from "./stun";

export { expect };

export interface Peer {
  name: string;
  context: BrowserContext;
  page: Page;
}

export interface PeerOptions {
  viewport?: { width: number; height: number };
  /** Emulates a phone: touch, mobile user agent, narrow viewport. */
  mobile?: boolean;
  /** Says it is another browser (Safari on an iPhone or a Mac, Firefox): for what the app offers by browser. */
  userAgent?: string;
  /** Trusts any certificate, as a browser trusts a node's that a person has set up properly (self-hosted nodes in tests). */
  ignoreHTTPSErrors?: boolean;
  /** Talks to the public Pkarr relays themselves instead of the test's relay (measurements only: the suite stays offline). */
  realRelays?: boolean;
  /** Asks a STUN server in the test process instead of Google's public ones, which may answer late (support/stun.ts). */
  localStun?: boolean;
  /**
   * Refuses the public Mainnet services the automatic wallets reach on their own (see `MAINNET_SERVICES`), at once:
   * a test that moves test coins only then never waits on them — a Mainnet wallet still busy with a slow server
   * holds the switch to Testnet behind it.
   */
  offlineMainnet?: boolean;
  /**
   * Runs Iroh through this relay (the e2e infra's, `endpoints.irohRelay`). Without it the page's peer has no Iroh:
   * the suite stays offline, and a browser is WebRTC only, as most specs expect. A deployed build (`E2E_WEB_URL`)
   * ignores the suite's storage switch, so there its Iroh gets a closed port instead (`NO_IROH_RELAY`).
   */
  irohRelay?: string;
  /**
   * Lets the web app's service worker run (apps/web/src/sw). The web project blocks it everywhere else: requests a worker
   * answers never reach `context.route`, which the stubs above rely on.
   */
  serviceWorkers?: "allow";
  /**
   * A browser profile on disk of its own (a temporary folder), as a person's browser has. WebKit keeps no Blob in
   * IndexedDB and has no origin-private file system in the in-memory contexts the suite otherwise uses (they behave
   * as a private window does), so a spec about stored files in WebKit asks for this.
   */
  persistent?: boolean;
  /** Runs on the new context before the app first loads: stubs and storage the app reads as it starts. */
  beforeOpen?: (context: BrowserContext) => Promise<void>;
}

/**
 * The public hosts identity cards read public profiles from (PUBLIC-PROFILES.md): the Pubky index, Bluesky's AppView and
 * CDN, the Nostr picture hosts and the default Nostr relays. Load public profiles is on by default and a card on screen
 * asks, so every peer refuses them unless its test answers them itself: a route or relay added later takes precedence.
 */
const PICTURE_HOSTS = new Set([...IMAGE_HOSTS, ...Object.values(IMAGE_REDIRECTS).flatMap(to => [...to])]);
export const PUBLIC_PROFILE_HOSTS: (RegExp | ((url: URL) => boolean))[] = [/^https:\/\/nexus\.pubky\.app\//, /^https:\/\/public\.api\.bsky\.app\//, /^https:\/\/cdn\.bsky\.app\//,
  url => url.protocol === "https:" && PICTURE_HOSTS.has(url.hostname)];
export const DEFAULT_NOSTR_RELAYS = ["wss://relay.damus.io", "wss://nos.lol"];

export async function guardPublicProfiles(context: BrowserContext): Promise<void> {
  for (const host of PUBLIC_PROFILE_HOSTS) await context.route(host, route => route.abort("blockedbyclient"));
  await context.routeWebSocket(url => DEFAULT_NOSTR_RELAYS.some(relay => url.href.startsWith(relay)), ws => { void ws.close({ code: 1008, reason: "No public relay in the test suite" }); });
}

/**
 * The real-money servers a new profile's first-run wallets reach (packages/browser/src/engine/walletSetup.ts): the
 * default Mainnet mints, the Ethereum RPC of Mainnet USDT, and Mainnet Esplora servers (Bitcoin on-chain).
 */
export const MAINNET_SETUP_SERVICES: ((url: URL) => boolean)[] = [
  ...MAINNET_MINTS.map((mint) => (url: URL) => url.origin === new URL(mint).origin),
  (url) => url.origin === "https://ethereum.publicnode.com",
  (url) => url.origin === "https://blockstream.info" && url.pathname.startsWith("/api/"),
  (url) => url.origin === "https://mempool.space" && url.pathname.startsWith("/api/"),
];

/** Requests that got past every stub to a real Mainnet server during this test. */
const mainnetReached: string[] = [];

/**
 * No test reaches a real Mainnet server by accident: registered before every stub, this answers only what gets past
 * them (a spec's own mocks, `mockMainnetMints`, an RPC stub, `offlineMainnet`, take precedence) and refuses it; the
 * `mainnetGuard` fixture then fails the test. The apps never make a profile's first-run wallets under test (an automated
 * browser), so nothing should get here.
 */
export async function guardMainnet(context: BrowserContext): Promise<void> {
  await context.route((url) => MAINNET_SETUP_SERVICES.some((reaches) => reaches(url)), (route) => {
    mainnetReached.push(route.request().url());
    return route.abort("blockedbyclient");
  });
}

/**
 * A closed port on this machine, as an Iroh relay: Iroh fails to start and the peer is WebRTC only (the extension's
 * way, e2e/support/extension.ts). For a deployed build, which ignores `ghostly-test-iroh`, so n0's relays stay unreached.
 */
export const NO_IROH_RELAY = "http://127.0.0.1:9/";
/**
 * Running against a deployed build (`E2E_WEB_URL` off this machine, https://app.ghostly.tools): a release build, which
 * reads none of the suite's storage switches. A build served here (test-affected.mjs, the perf specs) is the suite's.
 */
export const deployedBuild = !!process.env.E2E_WEB_URL && !/^https?:\/\/(localhost|127\.0\.0\.1)(:|\/|$)/.test(process.env.E2E_WEB_URL);

/** The Mainnet Ark server and explorer, and the Ethereum RPC: what a spec that moves test coins only refuses at once. */
export const MAINNET_SERVICES = [/^https:\/\/arkade\.computer\//, /^https:\/\/mempool\.space\/api\//, /^https:\/\/ethereum\.publicnode\.com/];

type Fixtures = {
  /** Fails the test if any request got past the stubs to the real Internet Archive (see `guardArchive`). Automatic. */
  archiveGuard: void;
  /** Fails the test if any request got past the stubs to a real Mainnet server (see `guardMainnet`). Automatic. */
  mainnetGuard: void;
  relay: LocalRelay;
  /** Opens Ghostly on the web as a new person: its own browser storage, the same relay as everyone else in the test. */
  peer: (name: string, options?: PeerOptions) => Promise<Peer>;
};

export async function openPeer(browser: Browser, relay: LocalRelay, baseURL: string, name: string, options: PeerOptions = {}): Promise<Peer> {
  const settings = {
    baseURL,
    // WebKit (e2e/playwright.webkit.config.ts) knows none of these by name and refuses a context that asks for them.
    permissions: browser.browserType().name() === "chromium" ? ["camera", "microphone", "clipboard-read", "clipboard-write"] : [],
    viewport: options.viewport ?? (options.mobile ? { width: 390, height: 844 } : { width: 1280, height: 800 }),
    ...(options.mobile ? { isMobile: true, hasTouch: true } : {}),
    ...(options.ignoreHTTPSErrors ? { ignoreHTTPSErrors: true } : {}),
    ...(options.serviceWorkers ? { serviceWorkers: options.serviceWorkers } : {}),
    ...(options.userAgent ? { userAgent: options.userAgent } : {}),
  };
  const context = options.persistent
    ? await browser.browserType().launchPersistentContext(mkdtempSync(join(tmpdir(), "ghostly-e2e-profile-")), settings)
    : await browser.newContext(settings);
  await guardMainnet(context);
  await guardArchive(context);
  await guardPublicProfiles(context);
  if (!options.realRelays) await relay.attach(context);
  if (options.localStun) await useLocalStun(context);
  await attachMint(context);
  await stubGifServices(context);
  if (options.offlineMainnet) for (const service of MAINNET_SERVICES) await context.route(service, (route) => route.abort("connectionrefused"));
  if (!options.irohRelay) await context.addInitScript(() => { try { localStorage.setItem("ghostly-test-iroh", "off"); } catch { /* opaque origin */ } });
  await options.beforeOpen?.(context);
  const page = context.pages()[0] ?? await context.newPage();
  page.on("pageerror", (error) => console.log(`  [${name}] ${error.message}`));
  // A busy CI runner on a quiet machine: E2E_CPU_RATE=6 runs every page six times slower (Chromium only).
  const cpuRate = Number(process.env.E2E_CPU_RATE) || 1;
  if (cpuRate > 1 && browser.browserType().name() === "chromium") await (await context.newCDPSession(page)).send("Emulation.setCPUThrottlingRate", { rate: cpuRate });
  await openApp(page, name, () => page.goto("/"));
  const irohRelay = options.irohRelay ?? (deployedBuild ? NO_IROH_RELAY : undefined);
  if (irohRelay) await setIrohRelay(page, irohRelay);
  return { name, context, page };
}

/**
 * Loads the app (`load`: a `goto`, or a `reload` once a test has set something the app reads as it starts) and waits
 * for it to draw. A load Chromium broke off because the machine's network changed under it is done again, at most
 * `MAX_BOOT_RELOADS` times, and the log says so (support/bootReload.ts); anything else fails as it always did.
 */
export async function openApp(page: Page, name: string, load: () => Promise<unknown>): Promise<void> {
  const ready = page.getByTitle("New Chat");
  const bootError = page.locator("[data-testid=boot-fallback][data-reason=error]");
  for (let reloads = 0; ; reloads++) {
    const failures: string[] = [];
    const failed = (request: Request) => { failures.push(request.failure()?.errorText ?? ""); };
    page.on("requestfailed", failed);
    let broken: unknown = null;
    let said: string | null = null;
    try {
      await load();
      await expect(ready.or(bootError)).toBeVisible();
      if (await bootError.isVisible()) said = await bootError.getByTestId("boot-fallback-details").inputValue().catch(() => "");
    } catch (error) {
      broken = error;
    } finally {
      page.off("requestfailed", failed);
    }
    if (broken === null && said === null) return;
    const why = shouldReloadAfterBoot(failures, said, reloads);
    if (!why) {
      if (broken !== null) throw broken;
      break;
    }
    console.log(`  ↻ ${testTitle()} [${name}] reloaded: ${why} during the first load`);
  }
  await expect(ready).toBeVisible();
}

function testTitle(): string {
  try { return base.info().title; } catch { return "(no test)"; }
}

/** Points this peer's Iroh at `relay` (Settings → Network), before it has a chat to start an endpoint for. */
export async function setIrohRelay(page: Page, relay: string): Promise<void> {
  await page.goto("/#/settings/network");
  await page.getByTestId("network-iroh-relays").fill(relay);
  await page.getByTestId("network-save").click();
  await expect(page.getByTestId("network-saved")).toBeVisible();
  await page.goto("/#/");
  await expect(page.getByTitle("New Chat")).toBeVisible();
}

/** A 1×1 GIF. */
export const GIF = Buffer.from("R0lGODlhAQABAIAAAP///wAAACH5BAEAAAAALAAAAAABAAEAAAICRAEAOw==", "base64");

/** GifCities' search and the Wayback Machine that serves its GIFs. */
export const GIFCITIES = "https://gifcities.archive.org/**";
export const WAYBACK = "https://web.archive.org/**";

/** Requests that got past every stub to the real Internet Archive during this test. */
const archiveReached: string[] = [];

/**
 * The Internet Archive's last word in `context`: registered before the stubs, so it answers only what gets past them
 * (a spec that unroutes a stub, a route that falls back) and refuses it; the `archiveGuard` fixture then fails the test.
 * GifCities limits requests per IP, and our runs share the IPs Ghostly's own apps use: our tests helped exhaust it.
 */
export async function guardArchive(context: BrowserContext): Promise<void> {
  for (const host of [GIFCITIES, WAYBACK]) {
    await context.route(host, (route) => {
      archiveReached.push(route.request().url());
      return route.abort("blockedbyclient");
    });
  }
}

/** GifCities answering `rows` as it does: a JSON list of GeoCities GIFs. */
export const gifCitiesAnswer = (rows: { gif: string; checksum: string; url_text: string }[]) =>
  ({ status: 200, contentType: "application/json", headers: { "access-control-allow-origin": "*" }, body: JSON.stringify(rows) });

/**
 * The page the Internet Archive answers with once an IP has asked too much: a 200 in HTML, not a 429. The real one has no
 * CORS header (2026-09-25), so a browser page never reads it; `route.abort("failed")` is what such a page sees. This one
 * can be read, as by a client CORS does not bind (Playwright would add the header to a fulfilled response anyway).
 */
export const GIFCITIES_RATE_LIMIT = {
  status: 200,
  contentType: "text/html",
  headers: { "access-control-allow-origin": "*" },
  body: "<!DOCTYPE html><html><head><title>Rate limit reached</title></head><body><h1>Rate limit reached</h1><p>You've reached the limit "
    + "for the number of requests that can be made in a short period of time. Please wait a moment and try again.</p></body></html>",
};

/** GifCities answers from here: one ghost, no network. */
async function stubGifServices(context: BrowserContext): Promise<void> {
  await context.route(GIFCITIES, (route) =>
    route.fulfill(gifCitiesAnswer([{ gif: "http://geocities.com/haunted/ghost.gif", checksum: "c1", url_text: "retro ghost" }])),
  );
  await context.route(WAYBACK, (route) => route.fulfill({ status: 200, contentType: "image/gif", body: GIF }));
}

export const test = base.extend<Fixtures>({
  archiveGuard: [async ({}, use) => {
    archiveReached.length = 0;
    await use();
    expect(archiveReached.splice(0), "requests that got past the stubs to the real Internet Archive (GifCities limits requests per IP)").toEqual([]);
  }, { auto: true }],
  mainnetGuard: [async ({}, use) => {
    mainnetReached.length = 0;
    await use();
    expect(mainnetReached.splice(0), "requests that got past the stubs to a real Mainnet server (mint, Ethereum RPC, Esplora)").toEqual([]);
  }, { auto: true }],
  relay: async ({}, use) => {
    const relay = new LocalRelay();
    await use(relay);
    relay.close();
  },
  peer: async ({ browser, relay, baseURL }, use) => {
    const opened: Peer[] = [];
    await use(async (name, options) => {
      const peer = await openPeer(browser, relay, baseURL!, name, options);
      opened.push(peer);
      return peer;
    });
    for (const peer of opened) await peer.context.close().catch(() => {});
  },
});

/** A phone held upright: a chat's header keeps the name, the connection, a voice call and ⋮ there (`usePhoneHeader` in the app). */
export const phoneHeader = (page: Page): Promise<boolean> => page.evaluate(() => matchMedia("(max-width: 480px)").matches);

/**
 * A control of a 1:1 chat's header that is a row of ⋮ on an upright phone: the video call (`call-video`), a bot's Tasks
 * (`chat-tasks`) and the contact's identities (`chat-identity-badges`). On screen when this resolves: on such a phone
 * ⋮ is opened for it. A click on the row closes the menu by itself. The connection (`connection-options`) is in the
 * header at every width.
 */
export async function headerControl(page: Page, id: string): Promise<Locator> {
  const control = page.getByTestId(id);
  if ((await phoneHeader(page)) && !(await control.isVisible())) await page.getByTestId("chat-options").filter({ visible: true }).click();
  return control;
}

/** The chat on screen is live: its connection control says "Connected · <transport>". */
export async function expectConnected(page: Page, timeout = 90_000): Promise<void> {
  await expect(page.getByTestId("connection-options")).toHaveAccessibleName(/Connected · /, { timeout });
}

/** `host` creates a chat, `guest` joins it with the invite code. Resolves once both have the chat open. */
export async function link(host: Peer, guest: Peer): Promise<void> {
  await host.page.getByTitle("New Chat").click();
  const invite = await copyInvite(host.page);
  await guest.page.getByRole("button", { name: "Join chat", exact: true }).first().click();
  await pasteInvite(guest.page, invite);
  await expect(guest.page.getByPlaceholder("Message…")).toBeVisible();
}

/**
 * Same, but the chat a legacy client can join. Sharing a local web app lives
 * only here for now: a paired link advertises `chat` and nothing else.
 */
export async function linkLegacy(host: Peer, guest: Peer): Promise<void> {
  // Historical session fixture: legacy creation is intentionally absent from the UI.
  const keys = createLink();
  const invite = encodeInviteCode(keys.invite);
  await host.page.evaluate(({ mine, invite }) => {
    const id = crypto.randomUUID().replaceAll("-", "");
    localStorage.setItem(`ghostly_${id}`, JSON.stringify({ id, mySeedB64: mine.seedB64, peerPubKeyB64: mine.peerPubKeyZ32, encKeyB64: mine.encKeyB64, messages: [], createdAt: Date.now() }));
    localStorage.setItem(`ghostly_invite_${id}`, invite);
    window.dispatchEvent(new Event("session-updated"));
    location.hash = `/chat/${id}`;
  }, { mine: keys.mine, invite });
  await guest.page.getByRole("button", { name: "Join chat", exact: true }).first().click();
  await pasteInvite(guest.page, invite);
  await expect(guest.page.getByPlaceholder("Message…")).toBeVisible();
}

/**
 * DHT only, chosen in the chat's Connection menu. There is one kind of chat and one invite (WISP 400): the
 * choice is made in a chat, at any time, never in its invite.
 */
export async function chooseDhtOnly(page: Page): Promise<void> {
  await setDhtOnly(page, true);
}

/**
 * DHT only on or off, in the panel of the chat header's connection control: it is one of the connection choices.
 * Off leaves it for Automatic, or for the one transport a browser runs (which is Automatic there too).
 */
export async function setDhtOnly(page: Page, on: boolean): Promise<void> {
  if ((await page.getByTestId("connection-menu").getAttribute("open")) === null) await page.getByTestId("connection-options").click();
  const panel = page.getByRole("dialog", { name: "Connection options" });
  const choice = panel.getByRole("radio", { name: "DHT only", exact: true });
  const back = panel.getByRole("radio", { name: "Automatic", exact: true }).or(panel.getByRole("radio", { name: "WebRTC", exact: true })).first();
  if ((await choice.isChecked()) !== on) await (on ? choice : back).click();
  await expect.poll(() => choice.isChecked()).toBe(on);
  await page.keyboard.press("Escape");
}

/** The open conversation, without the chat list (which previews the last message too). */
export const chat = (peer: Peer) => peer.page.locator(".chat-wallpaper");

/** A message's delivery mark (MessageBubble's clock, ticks or red circle), in one state or any. */
export const delivered = (scope: Locator, state: "sending" | "queued" | "waiting" | "held" | "sent" | "delivered" | "failed" = "delivered") =>
  scope.locator(`[data-testid="message-delivery"][data-delivery="${state}"]`);

export type WalletKind = "cashu" | "lightning" | "arkade" | "bark" | "spark" | "usdt" | "bitcoin" | "fedimint";
export type WalletNetwork = "mainnet" | "testnet";
/** A wallet's card: `arkade-testnet`, or a kind alone for the first card of that kind (a test that has one of it). */
export type WalletCardName = WalletKind | `${WalletKind}-${WalletNetwork}`;

/** A card of the wallet page's deck, by its name (see `WalletCardName`). */
export const walletCard = (page: Page, card: WalletCardName): Locator =>
  card.includes("-") ? page.getByTestId(`wallet-card-${card}`) : page.locator(`[data-testid^="wallet-card-${card}-"]`).first();

/**
 * The Wallets page's tab of one network (Mainnet | Testnet): only that network's deck is on the page. Nothing to do
 * when it is chosen already, or when the page has no tabs (a profile with no wallet yet). The page reads its wallets
 * after it opens (after a reload, slowly on a busy machine) and has no tabs until then: this waits for the tabs or the
 * first-wallet page before it decides there are none.
 */
export async function showNetwork(page: Page, network: WalletNetwork): Promise<void> {
  const tab = page.getByTestId(`wallet-network-${network}`);
  await expect(page.getByTestId("wallet-networks").or(page.getByTestId("wallet-first")).first()).toBeVisible();
  if (!await tab.count() || await tab.getAttribute("aria-selected") === "true") return;
  await tab.click();
  await expect(tab).toHaveAttribute("aria-selected", "true");
}

/**
 * The wallet is a page beside the chat list, like Settings: opening it puts the chat away. A card named with its
 * network is chosen on that network's tab; a kind alone, on whichever tab has one. The bar's Wallets button goes
 * back home from the Wallets page, so it is pressed only away from it (by the route, which a reload keeps before the
 * page is drawn). A phone has no such button: there the test has opened the page already. Until the page has read its
 * wallets it has no tabs, then shows the tab this device showed last (kept across reloads): the tab is chosen again
 * until the card is on the page.
 */
export async function openWallet(peer: Peer, card?: WalletCardName): Promise<void> {
  const page = peer.page;
  const chip = page.getByTestId("wallet-chip"), wallet = page.getByTestId("wallet");
  await expect(chip.or(wallet).first()).toBeVisible();
  if (!await wallet.isVisible() && await chip.getAttribute("aria-current") !== "page") await chip.click();
  await expect(wallet).toBeVisible();
  if (!card) return;
  const network = card.split("-")[1] as WalletNetwork | undefined;
  await expect(async () => {
    if (network) await showNetwork(page, network);
    else if (!await walletCard(page, card).count()) {
      const other = await page.getByTestId("wallet-network-panel").getAttribute("data-network") === "mainnet" ? "testnet" : "mainnet";
      await showNetwork(page, other);
    }
    await expect(walletCard(page, card)).toBeVisible({ timeout: 2_000 });
  }).toPass({ timeout: 60_000 });
  await walletCard(page, card).click();
}

export interface CreateWallet {
  /** Fedimint: the federation's invite code. */
  invite?: string;
  /** Lightning or on-chain: the source to pick (its id), and how to fill its form (the dialog's form area). */
  provider?: string;
  fill?: (form: Locator) => Promise<void>;
  /** How long its server may take to answer (the dialog then says it failed). */
  timeout?: number;
}

/**
 * Wallets → New → a network → a kind, as a person does: made in one click, checked by the app before its card
 * appears. A kind that needs one thing gets it (`invite`, or a source and its form). Nothing is done when the card
 * is there already, but for Lightning with a source (a network takes several Lightning cards: this adds one) and
 * Fedimint (another federation). A failure fails the test with the dialog's own message.
 */
export async function createWallet(peer: Peer, kind: WalletKind, network: WalletNetwork = "testnet", options: CreateWallet = {}): Promise<void> {
  const page = peer.page;
  await openWallet(peer);
  await showNetwork(page, network);
  // `wallet-card-lightning-testnet`, or one of several Lightning cards (`wallet-card-lightning-testnet-<card>`).
  const card = page.locator(`[data-testid="wallet-card-${kind}-${network}"], [data-testid^="wallet-card-${kind}-${network}-"]`);
  const another = kind === "fedimint" || (kind === "lightning" && !!options.provider);
  if (await card.count() && !another) return;
  await page.getByTestId("wallet-add").click();
  const dialog = page.getByTestId("new-wallet");
  await dialog.getByRole("radio", { name: network === "testnet" ? "Testnet" : "Mainnet" }).click();
  await dialog.getByTestId(`new-wallet-type-${kind}`).click();
  if (options.invite !== undefined) {
    await dialog.getByTestId("new-wallet-invite").fill(options.invite);
    await dialog.getByTestId("new-wallet-create").click();
  }
  if (options.provider || options.fill) {
    const form = dialog.getByTestId("new-wallet-provider");
    // By its test id: its name is translated (Source, Fonte…).
    const select = form.getByTestId("new-wallet-provider-select");
    if (options.provider && await select.count()) { await select.click(); await page.getByRole("option").and(page.locator(`[data-value="${options.provider}"]`)).click(); }
    await options.fill?.(form);
  }
  const error = dialog.getByTestId("new-wallet-error");
  await expect.poll(async () => await error.isVisible() ? `failed: ${await error.innerText()}` : await dialog.isVisible() ? "open" : "made", { timeout: options.timeout ?? 90_000 }).toBe("made");
  // New selects the card it made.
  await expect(card.and(page.locator('[aria-selected="true"]'))).toBeVisible();
}

/** A network's Lightning card chosen on the Wallets page: its only one, or the one of several whose face says `name`. */
export const lightningCard = (page: Page, network: WalletNetwork, name?: string | RegExp): Locator => {
  const cards = page.locator(`[data-testid="wallet-card-lightning-${network}"], [data-testid^="wallet-card-lightning-${network}-"]`);
  return name ? cards.filter({ hasText: name }) : cards;
};

/** Wallets on test networks, made with New: Testnet Cashu (the public test mint, answered by the suite's own) unless others are named. */
export async function useTestnet(peer: Peer, kinds: WalletKind[] = ["cashu"]): Promise<void> {
  for (const kind of kinds) await createWallet(peer, kind, "testnet");
}

/** What one "Get test coins" press brings from the test mint (packages/browser engine TEST_COINS_SATS). */
export const TEST_COINS = 10_000;

/**
 * Test sats into a Testnet Cashu wallet, the way a person gets them: "Get test coins" on its details, which asks the
 * test mint (the suite's own mint answers for the public one and pays its own invoice). Receive never fills a wallet
 * by itself any more. Leaves the Cashu card open.
 */
export async function getTestCoins(peer: Peer): Promise<void> {
  await openWallet(peer, "cashu-testnet");
  await peer.page.getByTestId("test-coins-get").click();
  await expect(peer.page.getByTestId("test-coins-result")).toHaveText(`+${TEST_COINS.toLocaleString("en-US")} test sats`, { timeout: 60_000 });
}

/** The Profile page, from the account bar: its Profile place opens the account switcher, whose first entry is the page. */
export async function openProfilePage(page: Page): Promise<void> {
  await page.getByTestId("account-profile").click();
  await page.getByTestId("profile-switcher-current").click();
}


/**
 * The fake Lightning and on-chain providers (regtest, in memory, Testnet only) join the source pickers:
 * how a test drives a source without a node. The flag is read when the engine starts, hence the reload.
 */
export async function useFakeProviders(peer: Peer): Promise<void> {
  await peer.page.evaluate(() => localStorage.setItem("ghostly-test-providers", "1"));
  await openApp(peer.page, peer.name, () => peer.page.reload());
}

/** Back from the wallet to the chat it was opened from. */
export async function openChat(peer: Peer): Promise<void> {
  if (await peer.page.getByTestId("wallet").isVisible()) await peer.page.goBack();
  await expect(chat(peer)).toBeVisible();
}

export async function say(peer: Peer, text: string): Promise<void> {
  const box = peer.page.getByPlaceholder("Message…");
  await box.fill(text);
  await box.press("Enter");
}

/** Both sides have seen each other's message and the WebRTC data link is up. */
export async function connect(a: Peer, b: Peer): Promise<void> {
  await say(b, `hello from ${b.name}`);
  await expect(chat(a).getByText(`hello from ${b.name}`)).toBeVisible();
  await say(a, `hello from ${a.name}`);
  await expect(chat(b).getByText(`hello from ${a.name}`)).toBeVisible();
  // A legacy chat says it in the strip, a paired one in the pairing banner.
  for (const peer of [a, b]) await expect(
    peer.page.getByTestId("datalink-state").filter({ hasText: "Peer to peer" })
      .or(peer.page.locator("[data-testid=connection-options][aria-label*=\"Connected · WebRTC\"]")),
  ).toBeVisible();
}
